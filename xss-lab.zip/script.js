/**
 * ============================================================
 *  The Debug Diary — XSS Training Lab
 *  script.js — Intentionally Vulnerable JavaScript
 *
 *  ⚠️  FOR LOCAL EDUCATIONAL USE ONLY
 *  This file demonstrates three XSS vulnerability patterns.
 *  DO NOT use these patterns in any real application.
 * ============================================================
 */

(function () {
  "use strict";

  /* ----------------------------------------------------------
     UTILITY: Detect which page we're on
  ---------------------------------------------------------- */
  const page = window.location.pathname.split("/").pop() || "index.html";

  /* ==========================================================
     1. REFLECTED XSS — search.html
        Reads ?q= from the URL and injects it with innerHTML.
        A payload like: ?q=<script>alert(1)</script> will run.
     ========================================================== */
  if (page === "search.html") {
    const resultsEl = document.getElementById("search-results");
    const searchInput = document.getElementById("searchInput");

    // Pre-fill the input with whatever is in the URL
    const params = new URLSearchParams(window.location.search);
    const query = params.get("q");

    if (searchInput && query !== null) {
      searchInput.value = query;
    }

    if (resultsEl) {
      if (query === null || query === "") {
        resultsEl.innerHTML =
          '<span style="color:var(--muted);font-style:italic;">Enter a search term above to see results.</span>';
      } else {
        // ⚠️ VULNERABLE: query is injected directly without sanitization
        resultsEl.innerHTML =
          `<p>Showing results for: <strong>${query}</strong></p>` +
          `<p style="color:var(--muted);font-size:.85rem;margin-top:8px;">` +
          `No posts matched — but your input was reflected into this page.` +
          `</p>`;
      }
    }
  }

  /* ==========================================================
     2. DOM-BASED XSS — dom.html
        Reads window.location.hash and writes it with innerHTML.
        Navigate to: dom.html#<img src=x onerror=alert(1)>
     ========================================================== */
  if (page === "dom.html") {
    const outputEl = document.getElementById("welcome-output");
    const hashInput = document.getElementById("hashInput");
    const applyBtn  = document.getElementById("applyHash");

    function renderHashGreeting() {
      if (!outputEl) return;

      const rawHash = window.location.hash.slice(1); // strip leading #
      const value   = decodeURIComponent(rawHash);

      if (!value) {
        outputEl.innerHTML =
          '<span style="color:var(--muted);font-style:italic;">' +
          'No hash value found. Add one to the URL, e.g. <code>#Alice</code></span>';
        return;
      }

      // ⚠️ VULNERABLE: hash value injected directly with innerHTML
      outputEl.innerHTML = `Hello, <strong>${value}</strong>! Welcome back to the Debug Diary.`;
    }

    // Run on page load
    renderHashGreeting();

    // Re-run whenever the hash changes (e.g. back/forward navigation)
    window.addEventListener("hashchange", renderHashGreeting);

    // "Apply" button updates the hash from the text input
    if (applyBtn && hashInput) {
      applyBtn.addEventListener("click", function () {
        const val = hashInput.value;
        // This updates the hash which triggers hashchange → re-render
        window.location.hash = encodeURIComponent(val);
      });
    }

    // Pre-fill the input with the current hash value
    if (hashInput && window.location.hash) {
      hashInput.value = decodeURIComponent(window.location.hash.slice(1));
    }
  }

  /* ==========================================================
     3. STORED XSS — post.html
        Comments saved to localStorage and rendered with innerHTML.
        Submit: <script>alert('stored')</script> as comment text.
     ========================================================== */
  if (page === "post.html") {
    const STORAGE_KEY    = "xss_lab_comments";
    const commentList    = document.getElementById("comment-list");
    const submitBtn      = document.getElementById("submitComment");
    const clearBtn       = document.getElementById("clearComments");
    const nameInput      = document.getElementById("commentName");
    const textInput      = document.getElementById("commentText");

    /* --- Load comments from localStorage --- */
    function loadComments() {
      try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
      } catch (e) {
        return [];
      }
    }

    /* --- Save comments to localStorage --- */
    function saveComments(comments) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(comments));
    }

    /* --- Render all stored comments — INTENTIONALLY VULNERABLE --- */
    function renderComments() {
      if (!commentList) return;

      const comments = loadComments();

      if (comments.length === 0) {
        commentList.innerHTML =
          '<div class="no-comments">No comments yet. Be the first!</div>';
        return;
      }

      // ⚠️ VULNERABLE: name and text inserted directly with innerHTML
      commentList.innerHTML = comments.map(function (c) {
        return (
          '<div class="comment-item">' +
            '<div class="comment-author">' + c.name + '</div>' +
            '<div class="comment-text">'   + c.text + '</div>' +
            '<div class="comment-timestamp">' + c.timestamp + '</div>' +
          '</div>'
        );
      }).join("");
    }

    /* --- Handle new comment submission --- */
    if (submitBtn) {
      submitBtn.addEventListener("click", function () {
        const name = nameInput ? nameInput.value.trim() : "Anonymous";
        const text = textInput ? textInput.value.trim() : "";

        if (!text) {
          alert("Please enter a comment.");
          return;
        }

        const comments = loadComments();

        // ⚠️ VULNERABLE: storing raw user input without sanitization
        comments.push({
          name:      name || "Anonymous",
          text:      text,
          timestamp: new Date().toLocaleString()
        });

        saveComments(comments);
        renderComments();

        // Clear form
        if (nameInput) nameInput.value = "";
        if (textInput) textInput.value = "";
      });
    }

    /* --- Clear all comments --- */
    if (clearBtn) {
      clearBtn.addEventListener("click", function () {
        if (confirm("Delete all comments? This cannot be undone.")) {
          localStorage.removeItem(STORAGE_KEY);
          renderComments();
        }
      });
    }

    // Initial render on page load
    renderComments();
  }

  /* ----------------------------------------------------------
     NOTE FOR STUDENTS
     -----------------
     To fix these vulnerabilities, replace innerHTML assignments
     with safe alternatives:

     Option A — textContent (for plain text only):
       element.textContent = userInput;

     Option B — DOM construction (safe for any structure):
       const el = document.createElement('strong');
       el.textContent = userInput;
       parent.appendChild(el);

     Option C — DOMPurify library (sanitize HTML):
       element.innerHTML = DOMPurify.sanitize(userInput);

     Each approach prevents arbitrary HTML/script injection by
     treating user input as data, not markup.
  ---------------------------------------------------------- */

})();
